package com.codingwithflutter.nested_navigation_demo_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
