import 'package:flutter/material.dart';

enum TabItem { std, teacher }

const Map<TabItem, String> tabName = {
  TabItem.std: 'Student',
  TabItem.teacher: 'Teacher',
  
};

const Map<TabItem, MaterialColor> activeTabColor = {
  TabItem.std: Colors.red,
  TabItem.teacher: Colors.green,
  
};
