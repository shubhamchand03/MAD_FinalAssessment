import 'package:flutter/material.dart';
import 'package:nested_navigation_demo_flutter/widgets.dart';

class ColorsListPage extends StatelessWidget {
  ColorsListPage({required this.color, required this.title, this.onPush});
  final MaterialColor color;
  final String title;
  final ValueChanged<int>? onPush;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            title,
          ),
          backgroundColor: color,
        ),
        body: Container(
          color: Colors.white,
          child:Padding(
          padding: EdgeInsets.all(12.0),
          child: Column(
            children: [
              TextFormField(
                style: simpleTextStyle(),
                decoration: textFieldInputDecoration(
                  'Name',
                  Icon(Icons.account_circle_outlined),
                ),
              ),
              
              
              SizedBox(height: 10.0),
              TextFormField(
                style: simpleTextStyle(),
                decoration: textFieldInputDecoration(
                  'Subject Name',
                  Icon(Icons.perm_identity_outlined),
                ),
                
              ),
              
              SizedBox(height: 10.0),
              TextFormField(
                style: simpleTextStyle(),
                decoration: textFieldInputDecoration(
                  'Assignment Name ',
                  Icon(Icons.confirmation_number_outlined),
                ),

                
              ),
              // Text('MAD II'),
              SizedBox(height: 10.0),
              
              TextFormField(
                // style: simpleTextStyle(),
                decoration: textFieldInputDecoration(
                  'Date and Time: ',
                  Icon(Icons.confirmation_number_outlined),
                ),
                
              ),
              // Text('Final Assessment'),
               TextFormField(
                // style: simpleTextStyle(),
                decoration: textFieldInputDecoration(
                  'Grade: ',
                  Icon(Icons.confirmation_number_outlined),
                ),
                
              ),
              SizedBox(height: 15.0),
              
              SizedBox(height: 10.0),
              Container(  
              margin: EdgeInsets.all(25),  
              child: FlatButton(  
                child: Text('Submit Assessment', style: TextStyle(fontSize: 20.0),),  
                color: Colors.blueAccent,  
                textColor: Colors.white,  
                onPressed: () {},  
              ),  

              
            ), 
            ],
          ),
        ),
        ));
  }

  
 
}
